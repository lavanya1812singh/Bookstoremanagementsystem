module Api
  module V1
    class AuthController < ApplicationController
      before_action :authorize_request, except: [:create, :reset_password, :index]
      skip_before_action :verify_authenticity_token, only: [:create, :destroy, :reset_password,:signup]

      def create
        email = "lavanya123singh@gmail.com"
        password = "vrihad@31"

        user = User.find_by(email: email)

        if user && user.authenticate(password)
          token = encode_token(user_id: user.id)
          render json: { token: token }
        else
          render json: { error: 'Invalid email or password' }, status: :unauthorized
        end
      end

      def signup
        user = User.new(user_params)

        if user.save
          token = encode_token(user_id: user.id)
          render json: { token: token }
        else
          render json: { error: user.errors.full_messages }, status: :unprocessable_entity
        end
      end

      def reset_password
        email = params[:email]
        new_password = params[:new_password]

        user = User.find_by(email: email)

        if user
          user.update(password: new_password)
          render json: { message: 'Password reset successful' }
        else
          render json: { error: 'User not found' }, status: :not_found
        end
      end

      def show
        render json: current_user
      end

      def index
        render json: { message: 'Welcome to the authentication API!' }
      end

      def destroy
        @current_user = nil
        head :no_content
      end

      private

      def user_params
        params.require(:user).permit(:email, :password)
      end

      def encode_token(payload)
        JWT.encode(payload, "46fa55decf8daebc42dae1bc9724e957c1f1459a2dd1d683c983188ad33064d3abe116c60703275898ad2cb6980aa1b45c996af8ba3623ceab869a10ee91d809")
      end

      def authorize_request
        return if action_name == 'create' || action_name == 'index'

        header = request.headers['Authorization']
        if header.present?
          token = header.split(' ').last
          begin
            decoded = JWT.decode(token, "46fa55decf8daebc42dae1bc9724e957c1f1459a2dd1d683c983188ad33064d3abe116c60703275898ad2cb6980aa1b45c996af8ba3623ceab869a10ee91d809")
            @current_user = User.find(decoded[0]['user_id'])
          rescue JWT::DecodeError => e
            render json: { error: 'Invalid token' }, status: :unauthorized
          rescue ActiveRecord::RecordNotFound => e
            render json: { error: 'User not found' }, status: :unauthorized
          end
        else
          render json: { error: 'Token not provided' }, status: :unauthorized
        end
      end
    end
  end
end

