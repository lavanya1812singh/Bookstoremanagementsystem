class BooksController < ApplicationController
  before_action :set_book, only: [:show, :edit, :update, :destroy]



  def index
    @books = Book.all
  end

  def show
  end

  def new
    @book = Book.new
  end

  def edit
  end

  def create
    @book = Book.new(book_params)
    if @book.save
      redirect_to @book, notice: 'Book was successfully created.'
    else
      render :new
    end
  end

  def update
    if @book.update(book_params)
      redirect_to @book, notice: 'Book was successfully updated.'
    else
      render :edit
    end
  end

  def destroy
    if current_user.can_destroy?(@book)
      @book.destroy
      redirect_to books_path, notice: 'Book was successfully destroyed.'
    else
      redirect_to books_path, alert: 'You are not authorized to delete this book.'
    end
  end

  private

  def set_book
    @book = Book.find(params[:id])
  end

  def book_params
    params.require(:book).permit(:title, :author, :genre)
  end


end
