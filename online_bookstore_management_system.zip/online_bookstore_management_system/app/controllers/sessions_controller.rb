class SessionsController < ApplicationController
  skip_before_action :authenticate_user!

  def create
    user = User.find_by(email: params[:email])
    if user&.authenticate(params[:password])
      token = JWT.encode({ user_id: user.id }, '46fa55decf8daebc42dae1bc9724e957c1f1459a2dd1d683c983188ad33064d3abe116c60703275898ad2cb6980aa1b45c996af8ba3623ceab869a10ee91d809', 'HS256')
      render json: { token: token }
    else
      render json: { error: 'Invalid credentials' }, status: :unauthorized
    end
  end
end