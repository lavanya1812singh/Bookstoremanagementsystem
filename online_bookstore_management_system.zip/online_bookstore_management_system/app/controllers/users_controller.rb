class UsersController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy]
  skip_before_action :verify_authenticity_token, only: [:create,:destroy]
  def index
    @users = User.all
  end

  def show
  end

  def new
    @user = User.new
  end

  def edit
  end

  def create
    @user = User.new(user_params)
    if @user.save
      session[:user_id] = @user.id
      NotificationMailer.welcome_email(@user).deliver_now
      redirect_to @user, notice: 'User was successfully created.'
    else
      render :new
    end
  end

  def update
    if @user.update(user_params)
      redirect_to @user, notice: 'User was successfully updated.'
    else
      render :edit
    end
  end

  def destroy
    @user.carts.each do |carts|
      carts.books.each do |book|
        book.line_items.destroy_all
      end
      carts.destroy
    end

    if @user.destroy
      redirect_to users_url, notice: 'User was successfully destroyed.'
    else
      redirect_to users_path, alert: 'Failed to delete user.'
    end
  end



  def upload_avatar
    @user.avatar.attach(params[:avatar])
    redirect_to @user, notice: 'Avatar was successfully uploaded.'
  end

  def remove_avatar
    @user.avatar.purge
    redirect_to @user, notice: 'Avatar was successfully removed.'
  end

  private

  def set_user
    @user = User.find(params[:id])
  end

  def user_params
    params.require(:user).permit(:name, :email, :password, :avatar)
  end
end
