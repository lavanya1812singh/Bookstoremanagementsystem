module Api::V1::RatingsHelper
end
