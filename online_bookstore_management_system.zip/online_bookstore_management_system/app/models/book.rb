class Book < ApplicationRecord
  has_many :carts
  has_many :ratings
  has_and_belongs_to_many :genres
  validates :title, presence: true
  validates :author, presence: true
end
