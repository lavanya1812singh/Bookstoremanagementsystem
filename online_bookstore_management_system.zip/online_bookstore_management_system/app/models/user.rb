class User < ApplicationRecord

  has_one_attached :avatar
  has_secure_password
  has_many :carts, dependent: :destroy
  has_many :ratings

  validates :email, presence: true, uniqueness: true
  validate :avatar_content_type

  def admin?
    role == 'admin'
  end

  private

  def avatar_content_type
    if avatar.attached? && !avatar.content_type.in?(%w(image/png image/jpeg image/jpg))
      errors.add(:avatar, 'must be a PNG or JPEG/JPG image')
    end
  end
end
