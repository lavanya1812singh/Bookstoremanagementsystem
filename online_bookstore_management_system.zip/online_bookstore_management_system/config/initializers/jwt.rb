require 'jwt'

module Jwt
  def self.encode(payload)
    JWT.encode(payload, "46fa55decf8daebc42dae1bc9724e957c1f1459a2dd1d683c983188ad33064d3abe116c60703275898ad2cb6980aa1b45c996af8ba3623ceab869a10ee91d809")
  end

  def self.decode(token)
    JWT.decode(token, "46fa55decf8daebc42dae1bc9724e957c1f1459a2dd1d683c983188ad33064d3abe116c60703275898ad2cb6980aa1b45c996af8ba3623ceab869a10ee91d809").first
  end
end
