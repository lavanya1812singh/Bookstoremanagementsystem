Rails.application.routes.draw do
  root 'books#index'
  resources :books
  resources :genres
  resources :users do
    patch 'update_avatar', on: :member
    post '/login', to: 'sessions#create'
    resources :carts
  end
  resources :ratings
  namespace :api, defaults: { format: :json } do
    namespace :v1 do
      resources :books
      delete '/books', to: 'books#destroy'
      resources :auth
      post '/login', to: 'auth#create'
      get '/auth', to: 'auth#show'
      delete '/auth', to: 'auth#destroy'
      get '/auth/reset_password', to: 'auth#reset_password'
      resources :genres, only: [:index, :show, :create, :destroy]
      resources :ratings, only: [:index, :show, :create, :update, :destroy]
      delete '/ratings/:id', to: 'ratings#destroy', as: 'delete_rating'
      resources :carts, only: [:index, :show, :create, :update]
      delete '/carts', to: 'carts#destroy'
      resources :users, only: [:index, :show, :create, :update, :destroy]
      delete '/users', to: 'users#destroy'
    end
  end
  get 'carts', to: 'carts#index'
  get 'carts/new', to: 'carts#new', as: 'new_cart'
  get 'carts/:id', to: 'carts#show', as: 'cart'
  get 'carts/:id/edit', to: 'carts#edit', as: 'edit_cart'
  post 'carts', to: 'carts#create'
  patch 'carts/:id', to: 'carts#update'
  delete 'carts/:id', to: 'carts#destroy'

end
