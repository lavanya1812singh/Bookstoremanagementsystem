class AddImageToImages < ActiveRecord::Migration[7.1]
  def change
    add_column :images, :image, :binary
  end
end
