# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end
# Create genres
Genre.create(name: 'Fiction')
Genre.create(name: 'Crime')
Genre.create(name: 'Romantic')
Genre.create(name: 'Tragedy')

User.all.each do|user|
  user.update(password: 'vrihad@31')
end

# Create users
user1 = User.create(name: 'Lavanya', email: 'lavanya123singh@gmail.com', password: 'vrihad@31')
user2 = User.create(name: 'Payal', email: 'dr.payalnayar@gmail.com', password: 'vrihad@31')

# Create books
book1 = Book.create(title: 'Harry Potter', author: 'J. K. Rowling', genre: 'Fiction')
book2 = Book.create(title: 'Sherlock Holmes', author: 'Arthur Conan Doyle', genre: 'Crime')
# Create carts
cart1 = Cart.create(user_id: user1.id)
cart2 = Cart.create(user_id: user2.id)
# Create ratings
Rating.create(user_id: user1.id, book_id: book1.id, value: 4, comment: "Good")
Rating.create(user_id: user2.id, book_id: book2.id, value: 5, comment: "Excellent")

