class NotificationMailerPreview < ActionMailer::Preview
  def welcome_email_preview
    user = User.first
    NotificationMailer.welcome_email(user)
  end
end
